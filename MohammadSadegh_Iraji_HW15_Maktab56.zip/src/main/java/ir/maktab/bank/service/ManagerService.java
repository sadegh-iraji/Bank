package ir.maktab.bank.service;

import ir.maktab.bank.base.service.BaseService;
import ir.maktab.bank.domain.Manager;

public interface ManagerService extends BaseService<Manager, Long> {
}
