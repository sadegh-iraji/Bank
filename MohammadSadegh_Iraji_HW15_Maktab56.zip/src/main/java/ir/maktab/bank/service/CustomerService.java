package ir.maktab.bank.service;

import ir.maktab.bank.base.service.BaseService;
import ir.maktab.bank.domain.Customer;

public interface CustomerService extends BaseService<Customer, Long> {
}
