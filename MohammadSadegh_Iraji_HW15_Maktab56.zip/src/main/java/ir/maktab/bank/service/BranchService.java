package ir.maktab.bank.service;

import ir.maktab.bank.base.service.BaseService;
import ir.maktab.bank.domain.Branch;

public interface BranchService extends BaseService<Branch, Long> {
}
