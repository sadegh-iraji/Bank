package ir.maktab.bank.repository;

import ir.maktab.bank.base.repository.BaseRepository;
import ir.maktab.bank.domain.Log;

public interface LogRepository extends BaseRepository<Log, Long> {

}
