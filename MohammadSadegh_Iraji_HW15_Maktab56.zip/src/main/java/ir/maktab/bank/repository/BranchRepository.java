package ir.maktab.bank.repository;

import ir.maktab.bank.base.repository.BaseRepository;
import ir.maktab.bank.domain.Branch;

public interface BranchRepository extends BaseRepository<Branch, Long> {
}
