package ir.maktab.bank.repository;

import ir.maktab.bank.base.repository.BaseRepository;
import ir.maktab.bank.domain.Manager;

public interface ManagerRepository extends BaseRepository<Manager, Long> {

}
