package ir.maktab.bank.domain.enumeration;

public enum UserType {
    CUSTOMER, EMPLOYEE, MANAGER, ADMIN
}
